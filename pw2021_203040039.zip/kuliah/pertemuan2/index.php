<?php
/*
Devi Indriawati
203040039
https://github.com/Deviindriawati/pw2021_203040039
pertemuan 2 - 11 februari 2021
Mempelajari mengenai sintaks PHP
*/
?>
<?php 
// Standar Ouput 
// echo, print
// print_r
// var-dumb

// Penulisan sintaks PHP
// 1.PHP didalam HTML
// 2.HTML didalam PHP

// Variabel dan Tipe Data
// Varibel
// tidak boleh diawali dengan angka, tapi boleh mengandung angka
// $Nama = "Devi Indriawati";
// echo'Hallo, Nama Saya $Nama';

// Operator
// aritmatika
// + - * / %
// $x= 10;
// $y= 20;
// echo $x * $y;

// penggabung string / concatenation / concat
// .
// $Nama_Depan = "Devi";
// $Nama_Belakang = "Indriawati";
// echo $Nama_Depan . " " . $Nama_Belakang;

// Assignment
// =, +=, -=, *=, /=, %=, .=
// $x = 1;
// $x -=5;
// echo $x;
// $Nama = "Devi";
// $Nama.= "";
// $Nama.= "Indriawati";
// echo $Nama;

// Perbandingan
// <, >, <=, >=, ==, !=
// var_dump(1 == "1");

//  Identitas
// ===, !==
// var_dump(1 === "1");


// Logika
// &&, ||, !
// $x = 30;
// var_dump($x < 20 || $x % 2 ==0);

?>

<!-<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Belajar PHP</title>
</head>
<body>
    <h1>Hallo, Selamat Datang <?php echo "Devi";?></h1>
</body>
</html>