<?php
/*
Devi Indriawati 
203040039
https://github.com/Deviindriawati/pw2021_203040039
Teknik informatika A
Pemograman Web
Pertemuan 7 - Request Method   GET & POSH
*/
?>

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>POST</title>
</head>
<body>

<h1>Selamat Datang, <?= $_POST["judul"]; ?>!</h1>

</body>
</html> 