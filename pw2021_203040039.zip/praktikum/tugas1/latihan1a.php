<?php
// Devi Indriawati
//203040039
// Shift Rabu 09.00 -10.00
?>

<?php for ($x=1; $x<=3; $x++){
    for ($z=1; $z<=3; $z++){
        echo "Ini perulangan ke ($x,$z)<br>";
    }
}
?>